import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './MaskGroup.module.css';
import { VectorIcon } from './VectorIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 27:3 */
export const MaskGroup: FC<Props> = memo(function MaskGroup(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.home}>
        <div className={classes.image}></div>
        <div className={classes.rectangle14}></div>
        <div className={classes.lOGIN}>LOG IN</div>
        <div className={classes.rectangle142}></div>
        <div className={classes.sIGNUP}>SIGN UP</div>
        <div className={classes.rahmatSejahteraSwalayanMenyedi}>
          Rahmat Sejahtera Swalayan menyediakan produk kebutuhan sehari-hari dengan harga terjangkau dan kualitas
          terbaik. Kami berkomitmen memberikan pengalaman berbelanja yang nyaman dengan layanan ramah dan promo menarik
          setiap minggu.
        </div>
        <div className={classes.wELCOME}>WELCOME</div>
        <div className={classes.rectangle12}></div>
        <div className={classes.rAHMATSEJAHTERASWALAYAN}>RAHMAT SEJAHTERA SWALAYAN</div>
        <div className={classes.rectangle13}></div>
        <div className={classes.pRODUCT}>PRODUCT</div>
        <div className={classes.cONTACT}>CONTACT</div>
        <div className={classes.hOME}>HOME</div>
        <div className={classes.rectangle3}></div>
        <div className={classes.line1}></div>
        <div className={classes.line2}></div>
        <div className={classes.vector}>
          <VectorIcon className={classes.icon} />
        </div>
      </div>
    </div>
  );
});
