<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Login</title>
    <style>
        /* CSS di sini */
        body {
            font-family: Arial, sans-serif;
            background-color: #d32f2f;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            width: 100%;
        }
        .form-wrapper {
            background-color: #f44336;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .form-wrapper h2 {
            color: white;
            margin-bottom: 20px;
        }
        .input-group {
            margin-bottom: 15px;
        }
        .input-group input {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }
        .forgot-password {
            display: block;
            color: #ffcdd2;
            margin-bottom: 20px;
            text-decoration: none;
        }
        .forgot-password:hover {
            text-decoration: underline;
        }
        button {
            background-color: white;
            color: #f44336;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #ffcdd2;
        }
        p {
            color: white;
            margin-top: 10px;
        }
        .social-icons img {
            width: 40px;
            margin: 0 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-wrapper">
            <h2>Log In</h2>
            <form id="loginForm" method="POST" action="login.php">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Number/ Email" required>
                </div>
                <div class="input-group">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <a href="#" class="forgot-password">Lupa sandi?</a>
                <button type="submit">LOG IN</button>
            </form>
            <p>Belum punya akun? <a href="register.php">Daftar</a></p>
            <p>Login dengan</p>
            <div class="social-icons">
                <a href="#"><img src="google-icon.png" alt="Google"></a>
                <a href="#"><img src="facebook-icon.png" alt="Facebook"></a>
            </div>
        </div>
    </div>

    <script>
        // JavaScript di sini
        document.getElementById('loginForm').addEventListener('submit', function(event) {
            // Contoh validasi sederhana sebelum pengiriman form
            var username = document.getElementsByName('username')[0].value;
            var password = document.getElementsByName('password')[0].value;
            if (username === '' || password === '') {
                event.preventDefault(); // Mencegah pengiriman form
                alert('Username dan password harus diisi!');
            }
        });
    </script>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        include 'database.php'; // Memanggil koneksi database dari file terpisah
        $conn = getDbConnection();
        $username = $_POST['username'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE email='$username' OR number='$username'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if ($password === $user['password']) {
                echo "<script>alert('Login berhasil!');</script>";
            } else {
                echo "<script>alert('Password salah');</script>";
            }
        } else {
            echo "<script>alert('Pengguna tidak ditemukan');</script>";
        }

        $conn->close();
    }
    ?>
</body>
</html>
