<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Registrasi</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f44336;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .container {
            width: 100%;
            max-width: 400px;
            background-color: #e57373;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-wrapper {
            text-align: center;
        }
        .form-wrapper h2 {
            margin-bottom: 20px;
            color: white;
        }
        .input-group {
            margin-bottom: 15px;
        }
        .input-group input {
            width: calc(100% - 20px);
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #ffebee;
        }
        button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #ff5252;
            color: white;
            cursor: pointer;
        }
        button:hover {
            background-color: #ff1744;
        }
        p {
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-wrapper">
            <h2>Daftar</h2>
            <form id="registerForm" method="POST" action="register.php">
                <div class="input-group">
                    <input type="text" name="number" placeholder="Number" required>
                </div>
                <div class="input-group">
                    <input type="email" name="email" placeholder="Email" required>
                </div>
                <div class="input-group">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <div class="input-group">
                    <input type="password" name="confirm_password" placeholder="Re-password" required>
                </div>
                <button type="submit">DAFTAR</button>
            </form>
            <p>Sudah punya akun? <a href="login.php">Log in</a></p>
        </div>
    </div>

    <script>
        document.getElementById('registerForm').addEventListener('submit', function(event) {
            var password = document.getElementsByName('password')[0].value;
            var confirm_password = document.getElementsByName('confirm_password')[0].value;
            if (password !== confirm_password) {
                event.preventDefault(); // Mencegah pengiriman form
                alert('Password dan Konfirmasi Password tidak cocok!');
            }
        });
    </script>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        include 'database.php';
        $conn = getDbConnection();
        $number = $_POST['number'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        if ($password !== $confirm_password) {
            echo "<script>alert('Password dan Konfirmasi Password tidak cocok!');</script>";
        } else {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            $sql = "SELECT * FROM users WHERE email='$email' OR number='$number'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<script>alert('Email atau Nomor sudah terdaftar');</script>";
            } else {
                $sql = "INSERT INTO users (number, email, password) VALUES ('$number', '$email', '$hashed_password')";
                if ($conn->query($sql) === TRUE) {
                    echo "<script>alert('Pendaftaran berhasil!');</script>";
                } else {
                    echo "<script>alert('Terjadi kesalahan saat mendaftar');</script>";
                }
            }
        }

        $conn->close();
    }
    ?>
</body>
</html>
