<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Login</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f44336;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .container {
            width: 100%;
            max-width: 400px;
            background-color: #e57373;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-wrapper {
            text-align: center;
        }
        .form-wrapper h2 {
            margin-bottom: 20px;
            color: white;
        }
        .input-group {
            margin-bottom: 15px;
        }
        .input-group input {
            width: calc(100% - 20px);
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #ffebee;
        }
        .forgot-password, .social-icons a {
            display: block;
            margin: 10px 0;
            color: white;
            text-decoration: none;
        }
        .forgot-password:hover, .social-icons a:hover {
            text-decoration: underline;
        }
        button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #ff5252;
            color: white;
            cursor: pointer;
        }
        button:hover {
            background-color: #ff1744;
        }
        .social-icons {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
        }
        .social-icons img {
            width: 30px;
            height: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-wrapper">
            <h2>Log In</h2>
            <form method="POST" action="login.php">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Number/ Email" required>
                </div>
                <div class="input-group">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <a href="#" class="forgot-password">Lupa sandi?</a>
                <button type="submit">LOG IN</button>
            </form>
            <p>Belum punya akun? <a href="register.php">Daftar</a></p>
            <p>Login dengan</p>
            <div class="social-icons">
                <a href="#"><img src="google-icon.png" alt="Google"></a>
                <a href="#"><img src="facebook-icon.png" alt="Facebook"></a>
            </div>
        </div>
    </div>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Ambil data dari form
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Contoh koneksi ke database (ganti dengan detail koneksi Anda)
        include 'database.php';
        $conn = getDbConnection();

        // Query untuk memeriksa pengguna
        $sql = "SELECT * FROM users WHERE email='$username' OR number='$username'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();

            // Periksa password (harusnya menggunakan password hash dalam implementasi nyata)
            if ($password === $user['password']) {
                // Login berhasil, set session atau tindakan lainnya
                echo "<script>alert('Login berhasil!');</script>";
            } else {
                echo "<script>alert('Password salah');</script>";
            }
        } else {
            echo "<script>alert('Pengguna tidak ditemukan');</script>";
        }

        $conn->close();
    }
    ?>

    <script>
        // Tambahkan interaktivitas atau validasi di sini jika diperlukan
    </script>
</body>
</html>
