<h2>Data Pelanggan </h2>

<table class="table table-bordered">

    <thead>
        <tr>
            <th>No.</th>
            <th>Nama</th>
            <th>Email</th>
            <th>No. HP</th>
            <th>Aksi</th>
        </tr>
</thead>
    <tbody>
        <tr>
            <td>x</td>
            <td>x</td>
            <td>x</td>
            <td>x</td>
            <td>x</td>
            <td>
            <a href="" class="btn btn-danger">hapus</a>
            </td>
        </tr>
    </tbody>
</table>