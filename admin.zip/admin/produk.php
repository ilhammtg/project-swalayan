<h2>Data Produk</h2>

<table class="table table-bordered">

    <thead>
        <tr>
            <th>No.</th>
            <th>Nama</th>
            <th>Harga</th>
            <th>Berat</th>
            <th>Foto</th>
            <th>Aksi</th>
        </tr>
</thead>
    <tbody>
        <tr>
            <td>x</td>
            <td>x</td>
            <td>x</td>
            <td>x</td>
            <td>x</td>
            <td>
                <a href="" class="btn-danger btn">hapus</a>
                <a href="" class="btn btn-warning">ubah</a>
            </td>
        </tr>
    </tbody>
</table>
<a href="index.php?halaman=tambahproduk" class="btn btn-primary">Tambah Data</a>