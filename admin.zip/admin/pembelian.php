<h2>Data Pembelian </h2>

<table class="table table-bordered">

    <thead>
        <tr>
            <th>No.</th>
            <th>Nama Pelanggan</th>
            <th>Tanggal</th>
            <th>Total</th>
            <th>Aksi</th>
        </tr>
</thead>
    <tbody>
        <tr>
            <td>x</td>
            <td>x</td>
            <td>x</td>
            <td>x</td>
            <td>x</td>
            <td>
            <a href="index.php?halaman=detail"class="btn btn-info">detail</a>
            </td>
        </tr>
    </tbody>
</table>